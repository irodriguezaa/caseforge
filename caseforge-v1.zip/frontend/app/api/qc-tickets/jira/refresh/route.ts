import { NextRequest, NextResponse } from "next/server";

const backendUrl = process.env.BACKEND_URL ?? "http://backend:8000";
const jiraRefreshTimeoutMs = 120_000;

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const response = await fetch(`${backendUrl}/api/v1/qc-tickets/jira/refresh${request.nextUrl.search}`, {
      method: "POST",
      cache: "no-store",
      headers: { "Content-Type": "application/json" },
      signal: AbortSignal.timeout(jiraRefreshTimeoutMs),
    });
    const body = await response.json();
    return NextResponse.json(body, { status: response.status });
  } catch {
    return NextResponse.json({ status: "error", message: "Backend unavailable" }, { status: 503 });
  }
}
