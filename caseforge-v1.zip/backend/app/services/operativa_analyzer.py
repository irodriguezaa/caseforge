"""Release Note Operativo extraction service.

Structurally different document family from the device-based Release RNs (WEB/iOS/tvOS/etc.)
handled by release_note_analyzer.py -- zero code reuse from there, this is a fresh analyzer for
a fresh table convention (BRF | EPC | Tipo | Alcance | Nota RTE, plus a second "BRFs en el
Scope" table and a TRI/"Incidentes productivos" table, none of which exist in the device-RN
family).

This module extracts (1) RN header fields for Paso 2 (entregable / name / cluster) and
(2) EPCs + qc_suggestion for Paso 4. Paso 3 fields (alcance funcional, dispositivos, dates,
Jira filter, instrucciones) are never inferred here -- the user fills them via the router.

Validated against exactly ONE real RN Operativo so far (OPE-AGOSTO-2026-AUP). Like the Release
RN analyzer's early rounds, the exclusion-keyword list and table-header patterns below are a
first, honest attempt -- expect to refine them against more real samples, not a finished ruleset.
"""

import io
import re
from typing import Any

import pdfplumber

# Table 1's header: "Brief Key | Clave | Tipo de Epica | Alcance | Nota RTE | Versiones..."
# This is the RN's own primary scope declaration (EPCs already in "Épicas Finalizadas": In
# Validate or Done, per the document's own cover text).
_EPC_TABLE_HEADER_MARKERS = ("BRIEF KEY", "TIPO DE EPICA")

# Table 2's header: "Clave | Tipo de BRF | Estado | Alcance | Nota RTE | Versiones..." -- a
# broader per-BRF listing that can include items NOT YET in "Épicas Finalizadas" (e.g. still "In
# Develop"), which is exactly where an explicit early-exclusion note like the real
# BRF-17294 case showed up. Enriches/extends the Table-1-derived rows rather than replacing them.
_BRF_TABLE_HEADER_MARKERS = ("TIPO DE BRF", "ESTADO")

# The "Incidentes productivos" / TRI table -- explicitly NOT an EPC Operativo, out of this
# engine's scope (same exclusion the real prior run applied manually).
_TRI_TABLE_HEADER_MARKERS = ("TIPO DE INCIDENCIA",)

# Anything else with a recognizable header (e.g. the VPN/credentials "Región" table at the end
# of this RN family) stops tracking entirely -- never treated as EPC data.
_STOP_HEADER_MARKERS = ("REGIÓN", "SERVER")

_BRF_KEY_RE = re.compile(r"\bBRF-\d+\b")
_EPC_KEY_RE = re.compile(r"\bEPC-\d+\b")
_STATUS_BADGES = ["In Validate", "In Develop", "In Progress", "Done", "To Do", "Cancelled", "Cancelado"]
_STATUS_RE = re.compile(r"(" + "|".join(re.escape(s) for s in _STATUS_BADGES) + r")\s*$", re.IGNORECASE)

# Generic Spanish phrasing for an explicit exclusion signal in Nota RTE. Deliberately short and
# broad rather than tied to this one document's exact wording -- expect to grow this list as
# more real RNs are seen, same as the Release RN analyzer's device-alias table.
#
# Regression: "no se prueba" was tried and REMOVED -- it false-matched the real BRF-17702 note
# ("Cambio en PROD, no se prueba en UAT"), which is purely informational about WHERE testing
# happens (UAT vs PROD), not whether QC applies at all. That exact ticket is the real-world case
# that taught us exclusion decisions like this one must stay human calls, never auto-inferred
# from adjacent wording -- so a phrase broad enough to catch it is wrong by definition.
_EXCLUSION_PHRASES = (
    "no requiere validaci",  # matches "validación"/"validacion" either way
    "fuera de scope",
    "fuera del scope",
    "sin validaci",
)

# Paso 2 header: only the cover page, never filename, never ticket-country inference.
_OPE_CODE_RE = re.compile(r"\b(OPE-[A-Z]+-\d{4}-[A-Z]+)\b", re.IGNORECASE)
_VERSION_LINE_RE = re.compile(r"Versi[oó]n\s+(OPE-[A-Z]+-\d{4}-[A-Z]+)", re.IGNORECASE)
_TITLE_LINE_RE = re.compile(
    r"^(OPE-[A-Z]+-\d{4}-[A-Z]+)\s+Release\s+notes\s*$", re.IGNORECASE | re.MULTILINE
)
_ENTREGABLE_LABEL_RE = re.compile(r"^Entregable\s*[:\-]\s*(.+)$", re.IGNORECASE | re.MULTILINE)
# Cover heading used as Entregable on this RN family (e.g. "Release Claro video").
# Explicitly excludes "Release notes" / "Release Note" so the title line is never reused.
_RELEASE_PRODUCT_HEADING_RE = re.compile(
    r"^Release\s+(?!notes?\b)(.{3,80})$", re.IGNORECASE | re.MULTILINE
)
_CLUSTER_FROM_OPE_SUFFIX = {
    "AUP": "AUP",
    "ANDINA": "Andina",
    "CENAM": "CENAM",
    "DOMINICANA": "Dominicana",
    "GLOBAL": "Global",
}


class RnHeader:
    """Cover-page identity. Any field may be None when the RN has no clear evidence."""

    __slots__ = ("entregable", "name", "cluster")

    def __init__(self, entregable: str | None, name: str | None, cluster: str | None) -> None:
        self.entregable = entregable
        self.name = name
        self.cluster = cluster


def extract_rn_header(pdf_bytes: bytes) -> RnHeader:
    """Reads page 1 only. Returns None for a field rather than guessing from the filename
    or from EPC ticket titles (those mention countries/clusters that are not the RN's own)."""
    page1 = _extract_page1_text(pdf_bytes)
    name = _extract_name(page1)
    cluster = _cluster_from_ope_code(name)
    entregable = _extract_entregable(page1)
    return RnHeader(entregable=entregable, name=name, cluster=cluster)


def _extract_page1_text(pdf_bytes: bytes) -> str:
    try:
        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            if not pdf.pages:
                return ""
            return pdf.pages[0].extract_text() or ""
    except Exception:
        return ""


def _extract_name(page1: str) -> str | None:
    version_match = _VERSION_LINE_RE.search(page1)
    if version_match:
        return version_match.group(1).upper()
    title_match = _TITLE_LINE_RE.search(page1)
    if title_match:
        return title_match.group(1).upper()
    # Last resort on page 1 only: a standalone OPE- code (still RN identity, not filename).
    code_match = _OPE_CODE_RE.search(page1)
    if code_match:
        return code_match.group(1).upper()
    return None


def _cluster_from_ope_code(name: str | None) -> str | None:
    if not name:
        return None
    suffix = name.rsplit("-", 1)[-1].upper()
    return _CLUSTER_FROM_OPE_SUFFIX.get(suffix)


def _extract_entregable(page1: str) -> str | None:
    labeled = _ENTREGABLE_LABEL_RE.search(page1)
    if labeled:
        candidate = re.sub(r"\s+", " ", labeled.group(1)).strip()
        if candidate:
            return candidate
    heading = _RELEASE_PRODUCT_HEADING_RE.search(page1)
    if heading:
        line = re.sub(r"\s+", " ", heading.group(0)).strip()
        if line and "http" not in line.lower():
            return line
    return None



class EpcCandidate:
    __slots__ = ("brf_key", "epc_key", "titulo", "alcance", "nota_rte", "estado_jira", "qc_suggestion")

    def __init__(
        self,
        brf_key: str,
        epc_key: str | None,
        titulo: str,
        alcance: str | None,
        nota_rte: str | None,
        estado_jira: str | None,
    ) -> None:
        self.brf_key = brf_key
        self.epc_key = epc_key
        self.titulo = titulo
        self.alcance = alcance
        self.nota_rte = nota_rte
        self.estado_jira = estado_jira
        self.qc_suggestion = _compute_suggestion(nota_rte, estado_jira)


def _compute_suggestion(nota_rte: str | None, estado_jira: str | None) -> str:
    """A SUGGESTION only -- the router/UI must always let the user override include_in_qc,
    regardless of what this returns. Checks exclusion language BEFORE status, since an explicit
    exclusion note matters even for an item that also happens to look "ready" by status."""
    if nota_rte:
        # PDF cell text wraps mid-phrase (real example: "fuera del\nscope"), so whitespace --
        # including newlines -- is normalized to single spaces before matching, otherwise a
        # line-wrapped exclusion phrase silently fails to match.
        lowered = re.sub(r"\s+", " ", nota_rte.lower())
        if any(phrase in lowered for phrase in _EXCLUSION_PHRASES):
            return "SUGERIDO_EXCLUIR"

    if estado_jira and estado_jira.strip().lower() in ("in validate", "done"):
        return "SUGERIDO_INCLUIR"

    # Anything else (unknown/missing status, or a Nota RTE that doesn't clearly say either way,
    # like the real "Cambio en PROD, no se prueba en UAT" case) is NOT auto-included or
    # auto-excluded -- it goes to the user.
    return "REQUIERE_REVISION"


def _extract_status(cell_text: str) -> tuple[str, str | None]:
    """Splits a trailing status badge (e.g. '...Nacional\\nIn Validate') from the rest of the
    cell's text. Returns (title_without_badge, status_or_None)."""
    match = _STATUS_RE.search(cell_text.strip())
    if not match:
        return cell_text.strip(), None
    status = match.group(1)
    title = cell_text[: match.start()].strip()
    return title, status


def _classify_header(header_row: list[str | None]) -> str | None:
    joined = " ".join((c or "").upper() for c in header_row)
    if any(marker in joined for marker in _STOP_HEADER_MARKERS):
        return "stop"
    if all(marker in joined for marker in _BRF_TABLE_HEADER_MARKERS):
        return "brf_table"
    if any(marker in joined for marker in _EPC_TABLE_HEADER_MARKERS):
        return "epc_table"
    if any(marker in joined for marker in _TRI_TABLE_HEADER_MARKERS):
        return "tri_table"
    return None


def analyze_operativa_rn(pdf_bytes: bytes) -> list[EpcCandidate]:
    """Walks every table in page order (same position-based sticky-section technique used for
    Release RNs, since this document has the identical page-break continuation problem), and
    returns one EpcCandidate per distinct BRF+EPC pair found across BOTH the "Épicas
    Finalizadas" table and the "BRFs en el Scope" table. TRI rows and anything after a stop
    marker (e.g. the VPN credentials table) are never included."""
    by_key: dict[tuple[str, str | None], EpcCandidate] = {}
    current_section: str | None = None

    try:
        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            for page in pdf.pages:
                for table in sorted(page.find_tables(), key=lambda t: t.bbox[1]):
                    rows = table.extract()
                    if not rows:
                        continue
                    header_kind = _classify_header(rows[0])
                    if header_kind == "stop":
                        current_section = None
                        continue
                    if header_kind is not None:
                        current_section = header_kind

                    if current_section == "epc_table":
                        for row in rows:
                            brf_idx = next(
                                (i for i, cell in enumerate(row) if cell and _BRF_KEY_RE.search(cell)), None
                            )
                            if brf_idx is None:
                                continue
                            brf_key = _BRF_KEY_RE.search(row[brf_idx]).group(0)  # type: ignore[union-attr]
                            epc_cell = row[brf_idx + 1] if len(row) > brf_idx + 1 else ""
                            epc_cell = epc_cell or ""
                            epc_match = _EPC_KEY_RE.search(epc_cell)
                            epc_key = epc_match.group(0) if epc_match else None
                            titulo_raw = epc_cell.split(":", 1)[1] if ":" in epc_cell else epc_cell
                            titulo, estado = _extract_status(titulo_raw)
                            # Columns after EPC, in order: Tipo de Epica (ignored), Alcance, Nota RTE.
                            alcance = (row[brf_idx + 3] or "").strip() or None if len(row) > brf_idx + 3 else None
                            nota_rte = (row[brf_idx + 4] or "").strip() or None if len(row) > brf_idx + 4 else None
                            key = (brf_key, epc_key)
                            by_key[key] = EpcCandidate(brf_key, epc_key, titulo, alcance, nota_rte, estado)

                    elif current_section == "brf_table":
                        for row in rows:
                            brf_idx = next(
                                (i for i, cell in enumerate(row) if cell and _BRF_KEY_RE.search(cell)), None
                            )
                            if brf_idx is None:
                                continue
                            col0 = row[brf_idx] or ""
                            brf_key = _BRF_KEY_RE.search(col0).group(0)  # type: ignore[union-attr]
                            rest = col0[_BRF_KEY_RE.search(col0).end():].lstrip(": ").strip()  # type: ignore[union-attr]
                            titulo, estado_from_badge = _extract_status(rest)
                            estado_col = (row[brf_idx + 2] or "").strip() if len(row) > brf_idx + 2 else ""
                            estado = estado_col or estado_from_badge
                            alcance = (row[brf_idx + 3] or "").strip() or None if len(row) > brf_idx + 3 else None
                            nota_rte = (row[brf_idx + 4] or "").strip() or None if len(row) > brf_idx + 4 else None

                            # If this BRF was already seen in the EPC table, ENRICH it (fill in
                            # missing estado/nota_rte) rather than overwrite what the EPC table
                            # already established -- Table 1 is the RN's primary scope
                            # declaration, Table 2 only adds detail Table 1 didn't have.
                            #
                            # Known limitation: when a page break truncates Table 1's status
                            # badge mid-word (real example: "...URLs de Times" cuts off before
                            # "hift, NPVR y Live\nIn Validate" on the next page), Table 1's own
                            # estado_jira comes back None, and this fallback fills it from Table
                            # 2's "Estado" column instead -- which may reflect a different point
                            # in the BRF's own dev cycle (e.g. "In Develop"), not necessarily the
                            # EPC's current state. When that happens the result correctly lands
                            # on REQUIERE_REVISION rather than a confident (possibly wrong)
                            # suggestion -- which is the safe outcome, but the "estado_jira" value
                            # shown to the user in that case should not be read as fully reliable.
                            existing_key = next((k for k in by_key if k[0] == brf_key), None)
                            if existing_key:
                                existing = by_key[existing_key]
                                if not existing.estado_jira and estado:
                                    existing.estado_jira = estado
                                    existing.qc_suggestion = _compute_suggestion(existing.nota_rte, existing.estado_jira)
                                if not existing.nota_rte and nota_rte:
                                    existing.nota_rte = nota_rte
                                    existing.qc_suggestion = _compute_suggestion(existing.nota_rte, existing.estado_jira)
                            else:
                                by_key[(brf_key, None)] = EpcCandidate(
                                    brf_key, None, titulo, alcance, nota_rte, estado
                                )
                    # tri_table rows are intentionally never collected -- out of scope per product decision.
    except Exception:
        pass  # Best-effort, same posture as the Release RN analyzer's table extraction.

    return list(by_key.values())
