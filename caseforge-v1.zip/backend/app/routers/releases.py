"""Release CRUD endpoints.

Deletion rule (per product decision): a Release can only be hard-deleted while it is still
DRAFT (cascading to its test cases/steps is safe at that point because nothing else can
reference them yet). Any release that has moved past DRAFT is considered to have activity and
must be moved to CANCELLED via PATCH instead of being deleted. This cascade behavior should be
re-reviewed before Sprint 3 once executions/evidence exist.
"""

from typing import Any

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.db import get_db
from app.models.deliverable import Deliverable
from app.models.release import Release, ReleaseStatus, ReleaseType
from app.models.release_analysis import ReleaseAnalysis
from app.models.test_case import TestCase
from app.routers.common import get_release_or_404
from app.schemas.release import (
    ReleaseAnalysisRead,
    ReleaseCreate,
    ReleaseNoteAnalyzeResponse,
    ReleaseRead,
    ReleaseUpdate,
    ReleaseWithCounts,
)
from app.services.release_note_analyzer import (
    RuleBasedPdfAnalyzer,
    calculate_business_days,
)

router = APIRouter(prefix="/api/v1/releases", tags=["releases"])

# Allowed forward transitions. DRAFT can also be removed entirely via DELETE (see below).
_VALID_TRANSITIONS: dict[ReleaseStatus, set[ReleaseStatus]] = {
    ReleaseStatus.DRAFT: {ReleaseStatus.IN_PROGRESS, ReleaseStatus.CANCELLED},
    ReleaseStatus.IN_PROGRESS: {ReleaseStatus.COMPLETED, ReleaseStatus.CANCELLED},
    ReleaseStatus.COMPLETED: set(),
    ReleaseStatus.CANCELLED: set(),
}

# Entregable / Tipo de Release / Release origen can only change while still DRAFT (product
# decision) -- same posture as the existing DRAFT-only hard-delete rule below.
_LINEAGE_FIELDS = {"deliverable_name", "release_type", "parent_release_id"}


def to_release_read(release: Release) -> ReleaseRead:
    """Populate deliverable_name and BE fields that are not columns on Release."""
    be = release.be_release
    read = ReleaseRead.model_validate(release)
    return read.model_copy(
        update={
            "deliverable_name": release.deliverable.name if release.deliverable else None,
            "swf": be.swf if be else None,
            "regresivo_scope": be.regresivo_scope if be else None,
            "affected_component": be.affected_component if be else None,
        }
    )


def _resolve_deliverable(name: str | None, db: Session) -> Deliverable | None:
    """Get-or-create by case-insensitive name match. No picker in this phase -- a typo creates
    a new Deliverable rather than silently merging, which is an accepted tradeoff for now."""
    if not name or not name.strip():
        return None
    normalized = name.strip()
    existing = db.execute(
        select(Deliverable).where(func.lower(Deliverable.name) == normalized.lower())
    ).scalar_one_or_none()
    if existing is not None:
        return existing
    deliverable = Deliverable(name=normalized)
    db.add(deliverable)
    try:
        db.flush()
    except IntegrityError:
        # Rare race: another request created the exact same name between our lookup and this
        # flush. The UNIQUE constraint caught it -- fall back to reusing that row instead of
        # surfacing a 500 for something that isn't really an error from the caller's view.
        db.rollback()
        return db.execute(
            select(Deliverable).where(func.lower(Deliverable.name) == normalized.lower())
        ).scalar_one()
    return deliverable


def _would_create_cycle(release_id: int, proposed_parent_id: int | None, db: Session) -> bool:
    """Walks up the proposed parent's own chain -- if it ever reaches release_id, setting
    proposed_parent_id as release_id's parent would create a cycle."""
    if proposed_parent_id is None:
        return False
    current_id: int | None = proposed_parent_id
    visited: set[int] = set()
    while current_id is not None:
        if current_id == release_id:
            return True
        if current_id in visited:
            break  # guards against an already-corrupt chain elsewhere; never infinite-loops
        visited.add(current_id)
        parent = db.get(Release, current_id)
        current_id = parent.parent_release_id if parent else None
    return False


def _validate_lineage(
    release_type: ReleaseType | None,
    parent_release_id: int | None,
    deliverable_id: int | None,
    db: Session,
    self_release_id: int | None = None,
) -> None:
    if release_type == ReleaseType.REVALIDACION:
        if parent_release_id is None:
            raise HTTPException(
                status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="Una Release de tipo Revalidación requiere una Release origen.",
            )
        if self_release_id is not None and parent_release_id == self_release_id:
            raise HTTPException(
                status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="Una Release no puede ser su propia Release origen.",
            )
        parent = db.get(Release, parent_release_id)
        if parent is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, detail="Release origen no encontrada.")
        if deliverable_id is None or parent.deliverable_id != deliverable_id:
            raise HTTPException(
                status.HTTP_409_CONFLICT,
                detail="La Release origen debe pertenecer al mismo Entregable.",
            )
        if self_release_id is not None and _would_create_cycle(self_release_id, parent_release_id, db):
            raise HTTPException(
                status.HTTP_409_CONFLICT,
                detail="Esa Release origen generaría un ciclo en la cadena de versiones del Entregable.",
            )
    elif release_type == ReleaseType.EVOLUTIVO and parent_release_id is not None:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Una Release de tipo Evolutivo no debe tener Release origen.",
        )


@router.post("/analyze-rn", response_model=ReleaseNoteAnalyzeResponse)
async def analyze_release_note(
    file: UploadFile = File(...),
) -> ReleaseNoteAnalyzeResponse:
    """Parses a Release Note PDF deterministically, extracting metadata and section counts.

    Does not hallucinate or predict test cases (strictly adheres to Phase 1 separation of
    concerns prior to .md QC engine integration).
    """
    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            detail="Solo se aceptan archivos PDF para el análisis de Release Note.",
        )

    content = await file.read()
    if not content:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, detail="El archivo PDF está vacío.")

    analyzer = RuleBasedPdfAnalyzer()
    extracted = analyzer.analyze(file.filename, content)

    return ReleaseNoteAnalyzeResponse(
        analysis=extracted,
        calculated_business_days=0,
    )


@router.get("", response_model=list[ReleaseWithCounts])
def list_releases(
    status_filter: ReleaseStatus | None = Query(default=None, alias="status"),
    platform: str | None = Query(default=None),
    include_be: bool = Query(default=False),
    db: Session = Depends(get_db),
) -> list[ReleaseWithCounts]:
    stmt = (
        select(Release, func.count(TestCase.id))
        .outerjoin(TestCase, TestCase.release_id == Release.id)
        .group_by(Release.id)
        .order_by(Release.created_at.desc())
    )
    if not include_be:
        stmt = stmt.where(Release.be_release_id.is_(None))
    if status_filter is not None:
        stmt = stmt.where(Release.status == status_filter)
    if platform is not None:
        stmt = stmt.where(Release.platform == platform)

    rows = db.execute(stmt).all()
    results: list[ReleaseWithCounts] = []
    for release, count in rows:
        latest_analysis = (
            db.execute(
                select(ReleaseAnalysis)
                .where(ReleaseAnalysis.release_id == release.id)
                .order_by(ReleaseAnalysis.created_at.desc())
            )
            .scalars()
            .first()
        )
        release_read = ReleaseRead.model_validate(release).model_dump()
        release_read["deliverable_name"] = release.deliverable.name if release.deliverable else None
        results.append(
            ReleaseWithCounts(
                **release_read,
                test_case_count=count,
                latest_analysis=(
                    ReleaseAnalysisRead.model_validate(latest_analysis)
                    if latest_analysis
                    else None
                ),
            )
        )
    return results


@router.post("", response_model=ReleaseRead, status_code=status.HTTP_201_CREATED)
def create_release(payload: ReleaseCreate, db: Session = Depends(get_db)) -> Release:
    release_dict = payload.model_dump(exclude={"analysis_data", "deliverable_name"})
    if release_dict.get("execution_days") is None and release_dict.get("start_date") and release_dict.get("end_date"):
        release_dict["execution_days"] = calculate_business_days(
            release_dict["start_date"], release_dict["end_date"]
        )

    deliverable = _resolve_deliverable(payload.deliverable_name, db)
    release_dict["deliverable_id"] = deliverable.id if deliverable else None
    _validate_lineage(payload.release_type, payload.parent_release_id, release_dict["deliverable_id"], db)

    release = Release(**release_dict)
    db.add(release)
    try:
        db.flush()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            detail="A release with this name, version and platform already exists.",
        ) from exc

    if payload.analysis_data is not None:
        analysis_dict = payload.analysis_data.model_dump()
        analysis_row = ReleaseAnalysis(release_id=release.id, **analysis_dict)
        db.add(analysis_row)

    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            detail="A release with this name, version and platform already exists.",
        ) from exc

    db.refresh(release)
    return release


@router.get("/{release_id}", response_model=ReleaseRead)
def get_release(release_id: int, db: Session = Depends(get_db)) -> ReleaseRead:
    release = get_release_or_404(release_id, db)
    return to_release_read(release)


@router.patch("/{release_id}", response_model=ReleaseRead)
def update_release(
    release_id: int, payload: ReleaseUpdate, db: Session = Depends(get_db)
) -> ReleaseRead:
    release = get_release_or_404(release_id, db)
    updates = payload.model_dump(exclude_unset=True)

    if _LINEAGE_FIELDS & updates.keys() and release.status != ReleaseStatus.DRAFT:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            detail="Entregable, Tipo de Release y Release origen solo pueden editarse mientras la Release está en DRAFT.",
        )

    new_status = updates.get("status")
    if new_status is not None and new_status != release.status:
        allowed = _VALID_TRANSITIONS.get(release.status, set())
        if new_status not in allowed:
            raise HTTPException(
                status.HTTP_409_CONFLICT,
                detail=(
                    f"Cannot transition release from {release.status.value} "
                    f"to {new_status.value}."
                ),
            )

    original_keys = set(updates.keys())
    if "deliverable_name" in updates:
        deliverable = _resolve_deliverable(updates.pop("deliverable_name"), db)
        updates["deliverable_id"] = deliverable.id if deliverable else None

    if _LINEAGE_FIELDS & original_keys:
        effective_type = updates.get("release_type", release.release_type)
        effective_parent = updates.get("parent_release_id", release.parent_release_id)
        effective_deliverable_id = updates.get("deliverable_id", release.deliverable_id)
        _validate_lineage(effective_type, effective_parent, effective_deliverable_id, db, self_release_id=release_id)

    for field, value in updates.items():
        setattr(release, field, value)

    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            detail="A release with this name, version and platform already exists.",
        ) from exc
    db.refresh(release)
    return to_release_read(release)


@router.delete("/{release_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_release(release_id: int, db: Session = Depends(get_db)) -> None:
    release = get_release_or_404(release_id, db)
    has_children = db.execute(
        select(Release.id).where(Release.parent_release_id == release_id)
    ).first()
    if has_children:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            detail="No se puede eliminar una Release que es origen de otras Releases (Revalidaciones).",
        )
    if release.status != ReleaseStatus.DRAFT:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            detail=(
                "Only DRAFT releases can be deleted. Releases with activity must be moved to "
                "CANCELLED instead of being deleted."
            ),
        )
    db.delete(release)
    db.commit()


@router.get("/{release_id}/analysis", response_model=ReleaseAnalysisRead)
def get_release_analysis(release_id: int, db: Session = Depends(get_db)) -> ReleaseAnalysis:
    get_release_or_404(release_id, db)
    analysis = (
        db.execute(
            select(ReleaseAnalysis)
            .where(ReleaseAnalysis.release_id == release_id)
            .order_by(ReleaseAnalysis.created_at.desc())
        )
        .scalars()
        .first()
    )
    if not analysis:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND,
            detail="No se encontró ningún análisis de Release Note para esta release.",
        )
    return analysis


@router.post("/{release_id}/generate-cases")
def generate_cases_from_rn(release_id: int, db: Session = Depends(get_db)) -> dict[str, Any]:
    """Stub endpoint prepared for the future .md-based QC Engine."""
    release = get_release_or_404(release_id, db)
    analysis = (
        db.execute(
            select(ReleaseAnalysis)
            .where(ReleaseAnalysis.release_id == release_id)
            .order_by(ReleaseAnalysis.created_at.desc())
        )
        .scalars()
        .first()
    )
    return {
        "status": "READY",
        "message": "Flujo de generación preparado. El motor QC v0.1 se conectará en la siguiente fase.",
        "release_id": release.id,
        "release_name": release.name,
        "validation_type": release.validation_type or "Smoke",
        "has_analysis": analysis is not None,
    }
